export interface Genero {
    id: number,
    nombre: string
}
