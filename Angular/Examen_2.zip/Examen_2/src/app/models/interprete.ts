export interface Interprete {
    id: number,
    nombre: string,
    apellidos: string,
    biografia: string,
    fecha_nacimiento: Date
}
